'use client'

import { getSession, signOut, useSession } from 'next-auth/react'
import Image from 'next/image'
import Link from 'next/link'
import { redirect } from 'next/navigation'
import React, { useState } from 'react'

export default function MenuButton() {
	const [openMenu, setOpenMenu] = useState(false)
	const { data: session } = useSession()
	return (
		<div>
			<div className='dropdown dropdown-end relative shadow-2xl'>
				<button onClick={() => setOpenMenu(!openMenu)}>
					<Image
						src={
							(session?.user.image as string) ||
							'https://axiumradonmitigations.com/wp-content/uploads/2015/01/icon-user-default.png'
						}
						width={60}
						height={60}
						alt='profile pic'
						className=' rounded-full'
					/>
				</button>

				<ul
					tabIndex={0}
					className={`${
						openMenu ? 'visible' : 'hidden'
					} [&>li]:p-4 bg-slate-800 rounded space-y-2 absolute menu-sm dropdown-content mt-3 z-[1] shadow bg-base-100 rounded-box w-52`}
				>

				
							<Link href='/reservation'>
								<li
									className=' p-2 flex justify-between items-center hover:bg-slate-400'
									onClick={() => setOpenMenu(!openMenu)}
								>
									<svg
										xmlns='http://www.w3.org/2000/svg'
										fill='none'
										viewBox='0 0 24 24'
										strokeWidth={1.5}
										stroke='currentColor'
										className='w-6 h-6'
									>
										<path
											strokeLinecap='round'
											strokeLinejoin='round'
											d='M7.5 3.75H6A2.25 2.25 0 003.75 6v1.5M16.5 3.75H18A2.25 2.25 0 0120.25 6v1.5m0 9V18A2.25 2.25 0 0118 20.25h-1.5m-9 0H6A2.25 2.25 0 013.75 18v-1.5M15 12a3 3 0 11-6 0 3 3 0 016 0z'
										/>
									</svg>
									<p>Find Space</p>
								</li>
							</Link>

							<Link href='/user-menu/my-reservations'>
								<li
									className=' p-2 flex justify-between items-center hover:bg-slate-400'
									onClick={() => setOpenMenu(!openMenu)}
								>
									<svg
										xmlns='http://www.w3.org/2000/svg'
										fill='none'
										viewBox='0 0 24 24'
										strokeWidth={1.5}
										stroke='currentColor'
										className='w-6 h-6'
									>
										<path
											strokeLinecap='round'
											strokeLinejoin='round'
											d='M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z'
										/>
									</svg>

									<p>My Reservations</p>
								</li>
							</Link>
							<Link href='/user-menu/my-transactions'>
								<li
									className=' p-2 flex justify-between items-center hover:bg-slate-400'
									onClick={() => setOpenMenu(!openMenu)}
								>
									<svg
										xmlns='http://www.w3.org/2000/svg'
										fill='none'
										viewBox='0 0 24 24'
										strokeWidth={1.5}
										stroke='currentColor'
										className='w-6 h-6'
									>
										<path
											strokeLinecap='round'
											strokeLinejoin='round'
											d='M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z'
										/>
									</svg>

									<p>My Transactions</p>
								</li>
							</Link>

							<Link href='/user-menu/wallet'>
								<li
									className=' p-2 flex justify-between items-center hover:bg-slate-400'
									onClick={() => setOpenMenu(!openMenu)}
								>
									<svg
										xmlns='http://www.w3.org/2000/svg'
										fill='none'
										viewBox='0 0 24 24'
										strokeWidth={1.5}
										stroke='currentColor'
										className='w-6 h-6'
									>
										<path
											strokeLinecap='round'
											strokeLinejoin='round'
											d='M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5z'
										/>
									</svg>

									<p>My Wallet</p>
								</li>
							</Link>

							<Link href='/user-menu/settings'>
								<li
									className=' p-2 flex justify-between items-center hover:bg-slate-400'
									onClick={() => setOpenMenu(!openMenu)}
								>
									<svg
										xmlns='http://www.w3.org/2000/svg'
										fill='none'
										viewBox='0 0 24 24'
										strokeWidth={1.5}
										stroke='currentColor'
										className='w-6 h-6'
									>
										<path
											strokeLinecap='round'
											strokeLinejoin='round'
											d='M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z'
										/>
										<path
											strokeLinecap='round'
											strokeLinejoin='round'
											d='M15 12a3 3 0 11-6 0 3 3 0 016 0z'
										/>
									</svg>

									<p>Profile Settings</p>
								</li>
							</Link>


					<Link href=''>
						<li
							className=' p-2 flex justify-between items-center hover:bg-slate-400'
							onClick={() => {
								signOut()
								localStorage.clear()
								redirect('/sign-in')
							}}
						>
							<svg
								xmlns='http://www.w3.org/2000/svg'
								fill='none'
								viewBox='0 0 24 24'
								strokeWidth={1.5}
								stroke='currentColor'
								className='w-6 h-6'
							>
								<path
									strokeLinecap='round'
									strokeLinejoin='round'
									d='M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75'
								/>
							</svg>

							<p>Sign Out</p>
						</li>
					</Link>
				</ul>
			</div>
		</div>
	)
}
